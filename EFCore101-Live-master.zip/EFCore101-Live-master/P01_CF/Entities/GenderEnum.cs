﻿namespace P01_CF.Entities
{
    public enum GenderEnum
    {
        E,
        K

    }
}
